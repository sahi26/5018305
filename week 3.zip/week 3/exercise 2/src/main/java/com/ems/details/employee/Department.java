package com.ems.details.employee;

import jakarta.persistence.*;
import java.util.List;

	

	@Entity
	@Table(name = "department")
	public class Department {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String name;

	    @OneToMany(mappedBy = "department")
	    private List<Employee> employees;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
}
