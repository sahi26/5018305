package com.ems.projection;

public interface DepartmentProjection {
    String getName();
}
