package com.ems.projection;

import org.springframework.beans.factory.annotation.Value;

public interface CustomEmployeeProjection {

    String getName();

    String getEmail();

    @Value("#{target.department.name}")
    String getDepartmentName();

    @Value("#{target.name + ' (' + target.email + ')'}")
    String getFormattedNameAndEmail();
}