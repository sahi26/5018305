package com.ems.projection;

public interface EmployeeProjection {
	String getName();
    String getEmail();
    String getDepartmentName();
}
