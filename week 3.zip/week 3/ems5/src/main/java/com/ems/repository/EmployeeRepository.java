package com.ems.repository;

import com.ems.details.employee.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
	 List<Employee> findByName(String name);

	    List<Employee> findByDepartmentName(String departmentName);

	    List<Employee> findByEmailContainingIgnoreCase(String emailPart);

	    List<Employee> findByNameStartingWith(String prefix);

	    List<Employee> findByNameAndDepartmentId(String name, Long departmentId);

	    @Query("SELECT e FROM Employee e WHERE e.name LIKE %:name%")
	    List<Employee> findEmployeesByPartialName(@Param("name") String name);

	    @Query("SELECT e FROM Employee e WHERE e.department.name = :departmentName")
	    List<Employee> findEmployeesByDepartmentName(@Param("departmentName") String departmentName);

	    @Query(value = "SELECT * FROM Employee e WHERE e.email LIKE %:domain", nativeQuery = true)
	    List<Employee> findEmployeesByEmailDomain(@Param("domain") String domain);

	    @Query(name = "Employee.findAllByDepartmentName")
	    List<Employee> findEmployeesByDepartmentNameNamed(@Param("departmentName") String departmentName);

	    @Query(name = "Employee.findAllByPartialName")
	    List<Employee> findEmployeesByPartialNameNamed(@Param("namePattern") String namePattern);
}
