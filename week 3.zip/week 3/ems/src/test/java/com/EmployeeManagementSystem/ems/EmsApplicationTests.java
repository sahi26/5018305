package com.EmployeeManagementSystem.ems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
