package com.ems.repository;

import com.ems.details.employee.Employee;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Page<Employee> findByName(String name, Pageable pageable);

    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);

    Page<Employee> findByEmailContainingIgnoreCase(String emailPart, Pageable pageable);
    
    
}