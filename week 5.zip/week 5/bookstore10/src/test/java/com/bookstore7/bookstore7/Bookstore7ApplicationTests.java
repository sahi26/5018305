package com.bookstore7.bookstore7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bookstore7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
