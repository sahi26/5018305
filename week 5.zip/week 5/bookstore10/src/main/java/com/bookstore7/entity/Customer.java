package com.bookstore7.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Version;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Customer {
    private Long id;
    private String name;
    private String email;
    private String phoneNumber;
	public void setId(long l) {
	}
	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setPhoneNumber(Object phoneNumber2) {
		// TODO Auto-generated method stub
		
	}
	public void setEmail(Object email2) {
		// TODO Auto-generated method stub
		
	}
	public void setName(Object name2) {
		// TODO Auto-generated method stub
		
	}

    @Version
    private Long version; 
}