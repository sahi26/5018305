package com.bookstore7.controller;

import com.bookstore7.dto.BookDTO;
import com.bookstore7.dto.BookMapper;
import com.bookstore7.entity.Book;
import com.bookstore7.exception.ResourceNotFoundException;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();
    private AtomicLong counter = new AtomicLong();

    // Create
    @PostMapping(consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        Book book = BookMapper.INSTANCE.bookDTOToBook(bookDTO);
        book.setId(counter.incrementAndGet()); // Simple ID generation for demo purposes
        books.add(book);

        BookDTO responseDTO = BookMapper.INSTANCE.bookToBookDTO(book);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
    }

    // Read All
    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<List<BookDTO>> getAllBooks() {
        List<BookDTO> bookDTOs = books.stream()
                                      .map(BookMapper.INSTANCE::bookToBookDTO)
                                      .peek(this::addHATEOASLinks)
                                      .toList();
        return ResponseEntity.ok(bookDTOs);
    }

    // Read by ID
    @GetMapping(value = "/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = books.stream()
                         .filter(b -> b.getId().equals(id))
                         .findFirst()
                         .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));

        BookDTO responseDTO = BookMapper.INSTANCE.bookToBookDTO(book);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.ok(responseDTO);
    }

    // Update
    @PutMapping(value = "/{id}", consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    public ResponseEntity<BookDTO> updateBook(@PathVariable Long id,  @RequestBody BookDTO bookDTO) {
        Book existingBook = books.stream()
                                 .filter(b -> b.getId().equals(id))
                                 .findFirst()
                                 .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));

        existingBook.setTitle(bookDTO.getTitle());
        existingBook.setAuthor(bookDTO.getAuthor());
        existingBook.setPrice(bookDTO.getPrice());
        existingBook.setIsbn(bookDTO.getIsbn());

        BookDTO responseDTO = BookMapper.INSTANCE.bookToBookDTO(existingBook);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.ok(responseDTO);
    }

    // Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        Book book = books.stream()
                         .filter(b -> b.getId().equals(id))
                         .findFirst()
                         .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));

        books.remove(book);
        return ResponseEntity.noContent().build();
    }

    // HATEOAS Link Addition
    private void addHATEOASLinks(BookDTO bookDTO) {
        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class)
                                                                  .getBookById(bookDTO.getId()))
                                         .withSelfRel();
        bookDTO.add(selfLink);

        Link allBooksLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class)
                                                                      .getAllBooks())
                                             .withRel("all-books");
        bookDTO.add(allBooksLink);
    }
}