package com.bookstore7.bookstore7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bookstore7Application {

	public static void main(String[] args) {
		SpringApplication.run(Bookstore7Application.class, args);
	}

}
