package com.bookstore7.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Version;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    private Long id;
    private String title;
    private String author;
    private Double price;
    private String isbn;
	public Object getId() {
		
		return null;
	}
	public void setId(Object object) {
		
	}
	public void setTitle(Object title2) {
		// TODO Auto-generated method stub
		
	}
	public void setAuthor(Object author2) {
		// TODO Auto-generated method stub
		
	}
	public void setPrice(Object price2) {
		// TODO Auto-generated method stub
		
	}
	 @Version
	    private Long version;
}