package com.bookstore11.service;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Service;

@Service
public class MetricsService {

    private final MeterRegistry meterRegistry;

    public MetricsService(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
        registerCustomMetrics();
    }

    private void registerCustomMetrics() {
        meterRegistry.gauge("bookstore.book.count", this, s -> s.getBookCount());
        meterRegistry.gauge("bookstore.customer.count", this, s -> s.getCustomerCount());
    }

    // Dummy methods for demonstration
    public int getBookCount() {
        // Implement your logic to get the book count
        return 100; // example value
    }

    public int getCustomerCount() {
        // Implement your logic to get the customer count
        return 50; // example value
    }
}