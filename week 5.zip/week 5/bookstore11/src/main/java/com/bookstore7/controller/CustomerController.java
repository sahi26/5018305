package com.bookstore7.controller;

import com.bookstore7.dto.CustomerDTO;
import com.bookstore7.dto.CustomerMapper;
import com.bookstore7.entity.Customer;
import com.bookstore7.exception.ResourceNotFoundException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    private List<Customer> customers = new ArrayList<>();
    private AtomicLong counter = new AtomicLong();

    // Create
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = CustomerMapper.INSTANCE.customerDTOToCustomer(customerDTO);
        customer.setId(counter.incrementAndGet()); // Simple ID generation for demo purposes
        customers.add(customer);

        CustomerDTO responseDTO = CustomerMapper.INSTANCE.customerToCustomerDTO(customer);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(responseDTO);
    }

    // Read All
    @GetMapping
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        List<CustomerDTO> customerDTOs = customers.stream()
                                                  .map(CustomerMapper.INSTANCE::customerToCustomerDTO)
                                                  .peek(this::addHATEOASLinks)
                                                  .toList();
        return ResponseEntity.ok(customerDTOs);
    }

    // Read by ID
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        Customer customer = customers.stream()
                                     .filter(c -> c.getId().equals(id))
                                     .findFirst()
                                     .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + id));

        CustomerDTO responseDTO = CustomerMapper.INSTANCE.customerToCustomerDTO(customer);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.ok(responseDTO);
    }

    // Update
    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable Long id, @Valid @RequestBody CustomerDTO customerDTO) {
        Customer existingCustomer = customers.stream()
                                             .filter(c -> c.getId().equals(id))
                                             .findFirst()
                                             .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + id));

        existingCustomer.setName(customerDTO.getName());
        existingCustomer.setEmail(customerDTO.getEmail());
        existingCustomer.setPhoneNumber(customerDTO.getPhoneNumber());

        CustomerDTO responseDTO = CustomerMapper.INSTANCE.customerToCustomerDTO(existingCustomer);
        addHATEOASLinks(responseDTO);
        return ResponseEntity.ok(responseDTO);
    }

    // Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        Customer customer = customers.stream()
                                     .filter(c -> c.getId().equals(id))
                                     .findFirst()
                                     .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + id));

        customers.remove(customer);
        return ResponseEntity.noContent().build();
    }

    private void addHATEOASLinks(CustomerDTO customerDTO) {
        // Link to self (GET /customers/{id})
        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                                                                  .getCustomerById(customerDTO.getId()))
                                         .withSelfRel();
        customerDTO.add(selfLink);

        // Link to all customers (GET /customers)
        Link allCustomersLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class)
                                                                        .getAllCustomers())
                                                 .withRel("all-customers");
        customerDTO.add(allCustomersLink);
    }
}