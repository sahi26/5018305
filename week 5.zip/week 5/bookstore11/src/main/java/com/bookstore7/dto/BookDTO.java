package com.bookstore7.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.hateoas.RepresentationModel;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
@Data
public class BookDTO extends RepresentationModel<BookDTO> {
    private Long id;

    @JsonProperty("book_title")
    private Long id;

    @NotNull
    @Size(min = 2, max = 100)
    private String title;

    @NotNull
    @Size(min = 2, max = 100)
    private String author;

    @NotNull
    private Double price;

    @NotNull
    @Size(min = 10, max = 13)
    private String isbn;
    

	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getPrice() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
}