package com.bookstore7.dto;

import lombok.Data;
import org.springframework.hateoas.RepresentationModel;
@Data
public class CustomerDTO extends RepresentationModel<CustomerDTO> {
	 private Long id;

	    @NotNull
	    @Size(min = 2, max = 100)
	    private String name;

	    @NotNull
	    @Email
	    private String email;

	    @NotNull
	    @Size(min = 10, max = 15)
	    private String phoneNumber;
	public Object getPhoneNumber() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}
}
