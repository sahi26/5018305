package com.bookstore7.service;

public class BookService {

}
