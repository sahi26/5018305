package com.bookstore14.integration;

import com.bookstore7.entity.Book;
import com.bookstore14.repository.BookRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import javax.transaction.Transactional;
import java.util.Optional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional // Rollback after each test
public class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    void setUp() {
        bookRepository.deleteAll();
    }

    @Test
    void testCreateBook() throws Exception {
        Book book = new Book(null, "Integration Test Book", "Test Author", 19.99, "1111111111");

        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(book)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Integration Test Book"));
    }

    @Test
    void testGetBookById() throws Exception {
        Book book = new Book(null, "Integration Test Book", "Test Author", 19.99, "1111111111");
        bookRepository.save(book);

        mockMvc.perform(get("/books/{id}", book.getId())
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Integration Test Book"))
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    void testUpdateBook() throws Exception {
        Book book = new Book(null, "Old Title", "Test Author", 19.99, "1111111111");
        bookRepository.save(book);

        book.setTitle("Updated Title");

        mockMvc.perform(put("/books/{id}", book.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(book)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Updated Title"));
    }

    @Test
    void testDeleteBook() throws Exception {
        Book book = new Book(null, "Delete Test Book", "Test Author", 19.99, "1111111111");
        bookRepository.save(book);

        mockMvc.perform(delete("/books/{id}", book.getId()))
                .andExpect(status().isNoContent());

        Optional<Book> deletedBook = bookRepository.findById(book.getId());
        assert(deletedBook.isEmpty());
    }
}
