package com.bookstore14.repository;

public class BookRepository {

}
