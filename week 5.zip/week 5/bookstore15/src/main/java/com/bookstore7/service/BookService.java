package com.bookstore7.service;

import java.util.List;

import com.bookstore7.dto.BookDTO;

public class BookService {

	public List<BookDTO> getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	public BookDTO createBook(BookDTO bookDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	public BookDTO updateBook(Long id, BookDTO bookDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	public BookDTO getBookById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		
	}

}
