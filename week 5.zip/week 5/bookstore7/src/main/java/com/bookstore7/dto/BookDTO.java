package com.bookstore7.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BookDTO {
    private Long id;

    @JsonProperty("book_title")
    private String title;

    private String author;

    private Double price;

    private String isbn;
}