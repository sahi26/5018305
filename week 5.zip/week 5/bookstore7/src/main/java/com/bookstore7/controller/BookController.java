package com.bookstore7.controller;

import com.bookstore7.dto.BookDTO;
import com.bookstore7.dto.BookMapper;
import com.bookstore7.entity.Book;
import com.bookstore7.exception.ResourceNotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    private List<Book> books = new ArrayList<>();

    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable Long id) {
        Book book = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id " + id));

        BookDTO bookDTO = BookMapper.INSTANCE.bookToBookDTO(book);
        return ResponseEntity.ok(bookDTO);
    }

    @PostMapping
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        Book book = BookMapper.INSTANCE.bookDTOToBook(bookDTO);
        book.setId((long) (books.size() + 1)); // Simple ID generation for demo purposes
        books.add(book);
        return ResponseEntity.status(HttpStatus.CREATED).body(BookMapper.INSTANCE.bookToBookDTO(book));
    }
}